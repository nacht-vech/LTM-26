import model.Account;
import model.Email;
import storage.FileManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

/**
 * FILE KHỞI CHẠY CHÍNH (ENTRY POINT & LOCAL SOCKET SERVER) - MainApp.java
 * Đã tách toàn bộ code giao diện Java Swing sang file riêng MailClientGUI.java.
 * File MainApp.java này chỉ đảm nhận:
 * 1. Khởi tạo FileManager (quản lý thư mục data/<username>.txt)
 * 2. Khởi chạy ngầm Local Socket Server cho SMTP (cổng 2525) và POP3 (cổng 1110)
 * 3. Gọi MailClientGUI.launch(fileManager) để bật giao diện đồ họa.
 */
public class MainApp {

    public static final int LOCAL_SMTP_PORT = 2525;
    public static final int LOCAL_POP3_PORT = 1110;
    private static volatile boolean localSocketServerRunning = false;

    public static void main(String[] args) {
        // 1. Khởi tạo bộ quản lý file dữ liệu (data/<username>.txt)
        FileManager fileManager = new FileManager();

        // 2. Khởi động ngầm Socket Server cho SMTP (2525) & POP3 (1110) để hỗ trợ test Socket mọi lúc
        startEmbeddedSmtpPop3SocketServers(fileManager);

        // 3. Khởi chạy giao diện Java Swing từ file riêng MailClientGUI.java
        MailClientGUI.launch(fileManager);
    }

    /**
     * Khởi chạy 2 luồng Socket Server nội bộ (SMTP cổng 2525 & POP3 cổng 1110).
     */
    public static synchronized void startEmbeddedSmtpPop3SocketServers(FileManager fileManager) {
        if (localSocketServerRunning) {
            return;
        }
        localSocketServerRunning = true;

        // Luồng lắng nghe kết nối SMTP tại cổng 2525
        Thread smtpThread = new Thread(() -> {
            try (ServerSocket server = new ServerSocket(LOCAL_SMTP_PORT)) {
                while (localSocketServerRunning) {
                    Socket client = server.accept();
                    new Thread(() -> handleSmtpSocketClient(client)).start();
                }
            } catch (Exception ignored) {
            }
        });
        smtpThread.setDaemon(true);
        smtpThread.start();

        // Luồng lắng nghe kết nối POP3 tại cổng 1110
        Thread pop3Thread = new Thread(() -> {
            try (ServerSocket server = new ServerSocket(LOCAL_POP3_PORT)) {
                while (localSocketServerRunning) {
                    Socket client = server.accept();
                    new Thread(() -> handlePop3SocketClient(client, fileManager)).start();
                }
            } catch (Exception ignored) {
            }
        });
        pop3Thread.setDaemon(true);
        pop3Thread.start();
    }

    private static void handleSmtpSocketClient(Socket socket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true)) {
            out.print("220 smtp.vku.localhost ESMTP VKU-Java-Mail-Server Ready\r\n");
            out.flush();
            String line;
            boolean inData = false;
            while ((line = in.readLine()) != null) {
                if (inData) {
                    if (".".equals(line)) {
                        inData = false;
                        out.print("250 2.0.0 OK: Message queued and saved\r\n");
                        out.flush();
                    }
                    continue;
                }
                String upper = line.toUpperCase();
                if (upper.startsWith("HELO") || upper.startsWith("EHLO")) {
                    out.print("250 Hello from VKU Local Socket SMTP Server\r\n");
                } else if (upper.startsWith("AUTH LOGIN")) {
                    out.print("334 VXNlcm5hbWU6\r\n");
                    in.readLine();
                    out.print("334 UGFzc3dvcmQ6\r\n");
                    in.readLine();
                    out.print("235 2.7.0 Authentication successful\r\n");
                } else if (upper.startsWith("MAIL FROM")) {
                    out.print("250 2.1.0 Sender OK\r\n");
                } else if (upper.startsWith("RCPT TO")) {
                    out.print("250 2.1.5 Recipient OK\r\n");
                } else if (upper.equals("DATA")) {
                    inData = true;
                    out.print("354 End data with <CR><LF>.<CR><LF>\r\n");
                } else if (upper.startsWith("QUIT")) {
                    out.print("221 2.0.0 Bye\r\n");
                    out.flush();
                    break;
                } else {
                    out.print("250 OK\r\n");
                }
                out.flush();
            }
        } catch (Exception ignored) {
        }
    }

    private static void handlePop3SocketClient(Socket socket, FileManager fm) {
        String currentPopUser = "alice";
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true)) {
            out.print("+OK VKU-Java-POP3-Server Ready on port " + LOCAL_POP3_PORT + "\r\n");
            out.flush();
            String line;
            while ((line = in.readLine()) != null) {
                String upper = line.toUpperCase();
                if (upper.startsWith("USER ")) {
                    currentPopUser = line.substring(5).trim();
                    out.print("+OK User accepted\r\n");
                } else if (upper.startsWith("PASS ")) {
                    out.print("+OK Pass accepted\r\n");
                } else if (upper.startsWith("STAT")) {
                    Account acc = fm.loadAccount(currentPopUser);
                    int count = acc != null ? acc.getInbox().size() : 0;
                    out.print("+OK " + count + " " + (count * 256) + "\r\n");
                } else if (upper.startsWith("LIST")) {
                    Account acc = fm.loadAccount(currentPopUser);
                    List<Email> inbox = acc != null ? acc.getInbox() : Collections.emptyList();
                    out.print("+OK " + inbox.size() + " messages\r\n");
                    for (int i = 0; i < inbox.size(); i++) {
                        Email e = inbox.get(i);
                        out.print((i + 1) + " 256 (From: " + e.getSender() + " | Subject: " + e.getSubject() + ")\r\n");
                    }
                    out.print(".\r\n");
                } else if (upper.startsWith("QUIT")) {
                    out.print("+OK POP3 Server signing off\r\n");
                    out.flush();
                    break;
                } else {
                    out.print("+OK\r\n");
                }
                out.flush();
            }
        } catch (Exception ignored) {
        }
    }
}