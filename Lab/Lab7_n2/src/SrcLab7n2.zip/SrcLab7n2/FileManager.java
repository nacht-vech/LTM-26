package storage;

import model.Account;
import model.Email;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Quản lý đọc/ghi dữ liệu cho từng tài khoản vào 1 file .txt duy nhất (data/<username>.txt).
 * Mọi thông tin: [ACCOUNT] (Password, CreatedAt, LastLogin), [INBOX] và [SENT] (kèm File đính kèm)
 * đều được lưu chung và cập nhật trực tiếp tại chỗ trong file của tài khoản đó.
 */
public class FileManager {
    private static final String DATA_DIR = "data/";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public FileManager() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        ensureSampleAccounts();
    }

    public static String getCurrentTime() {
        return LocalDateTime.now().format(FORMATTER);
    }

    public File getAccountFile(String username) {
        return new File(DATA_DIR + username + ".txt");
    }

    public boolean userExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }
        return getAccountFile(username.trim()).exists();
    }

    /**
     * Khởi tạo sẵn 2 tài khoản mẫu (alice và bob) để người dùng có thể test gửi/nhận thư ngay trên GUI.
     */
    private void ensureSampleAccounts() {
        try {
            if (!userExists("alice")) {
                createAccount("alice", "123456");
            }
            if (!userExists("bob")) {
                createAccount("bob", "123456");
            }
        } catch (IOException ignored) {
        }
    }

    // Tạo tài khoản mới - Khởi tạo file .txt riêng cho User
    public synchronized boolean createAccount(String username, String password) throws IOException {
        username = username.trim();
        if (userExists(username)) {
            return false;
        }
        String now = getCurrentTime();
        Account newAccount = new Account(username, password, now, now);
        saveAccount(newAccount);
        return true;
    }

    // Load TOÀN BỘ dữ liệu của tài khoản từ 1 file .txt duy nhất
    public synchronized Account loadAccount(String username) throws IOException {
        File file = getAccountFile(username);
        if (!file.exists()) {
            return null;
        }

        String password = "";
        String createdAt = "";
        String lastLogin = "";

        Account account = null;
        String currentSection = "";

        String eTime = "", eSender = "", eReceiver = "", eSubject = "", eBody = "", eFile = "";

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                if (line.equalsIgnoreCase("[ACCOUNT]")) {
                    currentSection = "ACCOUNT";
                    continue;
                } else if (line.equalsIgnoreCase("[INBOX]")) {
                    currentSection = "INBOX";
                    continue;
                } else if (line.equalsIgnoreCase("[SENT]")) {
                    currentSection = "SENT";
                    continue;
                }

                if ("ACCOUNT".equals(currentSection)) {
                    if (line.startsWith("Password=")) password = line.substring(9);
                    else if (line.startsWith("CreatedAt=")) createdAt = line.substring(10);
                    else if (line.startsWith("LastLogin=")) lastLogin = line.substring(10);

                    if (!password.isEmpty() && !createdAt.isEmpty() && !lastLogin.isEmpty() && account == null) {
                        account = new Account(username, password, createdAt, lastLogin);
                    }
                } else if ("INBOX".equals(currentSection) || "SENT".equals(currentSection)) {
                    if (account == null) {
                        account = new Account(username, password, createdAt, lastLogin);
                    }

                    if (line.equals("---MSG---")) {
                        eTime = ""; eSender = ""; eReceiver = ""; eSubject = ""; eBody = ""; eFile = "";
                    } else if (line.equals("---END_MSG---")) {
                        Email email = new Email(eTime, eSender, eReceiver, eSubject, decodeMultiline(eBody), eFile);
                        if ("INBOX".equals(currentSection)) {
                            account.getInbox().add(email);
                        } else {
                            account.getSent().add(email);
                        }
                    } else {
                        if (line.startsWith("Time=")) eTime = line.substring(5);
                        else if (line.startsWith("Sender=")) eSender = line.substring(7);
                        else if (line.startsWith("Receiver=")) eReceiver = line.substring(9);
                        else if (line.startsWith("Subject=")) eSubject = line.substring(8);
                        else if (line.startsWith("Body=")) eBody = line.substring(5);
                        else if (line.startsWith("File=")) eFile = line.substring(5);
                    }
                }
            }
        }

        if (account == null) {
            account = new Account(username, password, createdAt, lastLogin);
        }

        return account;
    }

    // Ghi đè toàn bộ dữ liệu cập nhật vào file .txt duy nhất của User
    public synchronized void saveAccount(Account account) throws IOException {
        File file = getAccountFile(account.getUsername());
        try (BufferedWriter bw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8))) {

            bw.write("[ACCOUNT]\n");
            bw.write("Password=" + sanitizeSingleLine(account.getPassword()) + "\n");
            bw.write("CreatedAt=" + sanitizeSingleLine(account.getCreatedAt()) + "\n");
            bw.write("LastLogin=" + sanitizeSingleLine(account.getLastLogin()) + "\n\n");

            bw.write("[INBOX]\n");
            for (Email e : account.getInbox()) {
                writeEmailBlock(bw, e);
            }
            bw.write("\n");

            bw.write("[SENT]\n");
            for (Email e : account.getSent()) {
                writeEmailBlock(bw, e);
            }
        }
    }

    private void writeEmailBlock(BufferedWriter bw, Email e) throws IOException {
        bw.write("---MSG---\n");
        bw.write("Time=" + sanitizeSingleLine(e.getTime()) + "\n");
        bw.write("Sender=" + sanitizeSingleLine(e.getSender()) + "\n");
        bw.write("Receiver=" + sanitizeSingleLine(e.getReceiver()) + "\n");
        bw.write("Subject=" + sanitizeSingleLine(e.getSubject()) + "\n");
        bw.write("Body=" + encodeMultiline(e.getBody()) + "\n");
        bw.write("File=" + sanitizeSingleLine(e.getAttachedFile()) + "\n");
        bw.write("---END_MSG---\n");
    }

    private String sanitizeSingleLine(String s) {
        if (s == null) return "";
        return s.replace("\r", " ").replace("\n", " ").trim();
    }

    private String encodeMultiline(String s) {
        if (s == null) return "";
        return s.replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n");
    }

    private String decodeMultiline(String s) {
        if (s == null) return "";
        return s.replace("\\n", "\n");
    }

    /**
     * Đọc nguyên văn nội dung file data/<username>.txt để hiển thị trực tiếp lên giao diện GUI.
     */
    public synchronized String readRawAccountFile(String username) {
        File file = getAccountFile(username);
        if (!file.exists()) {
            return "(File " + file.getPath() + " chưa tồn tại)";
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (IOException e) {
            sb.append("Lỗi đọc file: ").append(e.getMessage());
        }
        return sb.toString();
    }

    /**
     * Lấy danh sách tất cả username đã đăng ký (quét thư mục data/*.txt) để gợi ý người nhận trên GUI.
     */
    public synchronized List<String> listAllUsernames() {
        List<String> users = new ArrayList<>();
        File dir = new File(DATA_DIR);
        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".txt"));
        if (files != null) {
            for (File f : files) {
                String name = f.getName();
                users.add(name.substring(0, name.length() - 4));
            }
        }
        return users;
    }
}