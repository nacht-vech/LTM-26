import model.Account;
import model.Email;
import protocol.Pop3Client;
import protocol.SmtpClient;
import storage.FileManager;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.util.List;

/**
 * FILE GIAO DIỆN ĐỒ HỌA RIÊNG BIỆT (JAVA SWING UI) - MailClientGUI.java
 * Tách riêng toàn bộ code Java Swing khỏi MainApp.java để dễ dàng chỉnh sửa màu sắc,
 * bố cục, font chữ, kích thước cửa sổ và các sự kiện nút bấm.
 */
public class MailClientGUI extends JFrame {

    // =========================================================================
    // 1. CẤU HÌNH GIAO DIỆN TẬP TRUNG (DỄ DÀNG CHỈNH SỬA MÀU SẮC & KÍCH THƯỚC)
    // =========================================================================
    public static final int WINDOW_WIDTH = 1300;
    public static final int WINDOW_HEIGHT = 820;

    public static final Color COLOR_BG_MAIN = new Color(241, 245, 249);
    public static final Color COLOR_HEADER_BG = new Color(15, 23, 42);
    public static final Color COLOR_PRIMARY_BTN = new Color(2, 132, 199);
    public static final Color COLOR_SUCCESS_BTN = new Color(21, 128, 61);
    public static final Color COLOR_CONSOLE_BG = new Color(15, 23, 42);
    public static final Color COLOR_CONSOLE_TEXT = new Color(56, 189, 248);

    public static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 15);
    public static final Font FONT_TAB = new Font("SansSerif", Font.BOLD, 13);
    public static final Font FONT_NORMAL = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font FONT_MONO = new Font("Monospaced", Font.PLAIN, 13);

    // =========================================================================
    // 2. CÁC ĐỐI TƯỢNG XỬ LÝ NGHIỆP VỤ (MODEL / PROTOCOL / STORAGE)
    // =========================================================================
    private final FileManager fileManager;
    private Account currentUser;
    private final SmtpClient smtpClient;
    private final Pop3Client pop3Client;

    // =========================================================================
    // 3. CÁC COMPONENT GIAO DIỆN SWING
    // =========================================================================
    private JLabel lblTopAccountBanner;
    private JTabbedPane mainTabs;
    private JTextArea txtProtocolConsole;

    // Các thành phần của Tab 1: Hộp thư đến (POP3 Inbox)
    private DefaultTableModel modelInbox;
    private JTable tblInbox;
    private JTextArea txtInboxDetail;

    // Các thành phần của Tab 2: Soạn & Gửi Email / File (SMTP Compose)
    private JComboBox<String> cbSendMode;
    private JPanel pnlExternalSmtpConfig;
    private JTextField txtSmtpHost;
    private JTextField txtSmtpPort;
    private JTextField txtSmtpAuthUser;
    private JPasswordField txtSmtpAuthPass;
    private JComboBox<String> cbReceiver;
    private JTextField txtSubject;
    private JTextArea txtBody;
    private JTextField txtAttachment;

    // Các thành phần của Tab 3: Hộp thư đã gửi (Sent Mailbox)
    private DefaultTableModel modelSent;
    private JTable tblSent;
    private JTextArea txtSentDetail;

    // Các thành phần của Tab 4: Phân tích URL (diachi.java) & InetAddress (inet.java)
    private JTextField txtNetInput;
    private DefaultTableModel modelUrlProps;
    private DefaultTableModel modelInetProps;
    private JTextArea txtNetConsole;

    // Các thành phần của Tab 5: Thông tin Tài khoản & Xem trực tiếp File .txt
    private JLabel lblAccUser;
    private JLabel lblAccPass;
    private JLabel lblAccCreated;
    private JLabel lblAccLastLogin;
    private JLabel lblAccFilePath;
    private JLabel lblAccInboxCount;
    private JLabel lblAccSentCount;
    private JTextArea txtRawAccountFile;

    public MailClientGUI(FileManager fileManager, Account loggedInUser) {
        this.fileManager = fileManager;
        this.currentUser = loggedInUser;
        this.smtpClient = new SmtpClient();
        this.pop3Client = new Pop3Client();

        setTitle("VKU Mail Client (SMTP & POP3 GUI) - Tài khoản: " + currentUser.getUsername()
                + " | File riêng: data/" + currentUser.getUsername() + ".txt");
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setMinimumSize(new Dimension(1040, 680));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initMainLayout();
        refreshAllMailAndFileViews();
        runPop3FetchOnGui();
    }

    /**
     * Khởi tạo bố cục tổng thể của cửa sổ chính.
     */
    private void initMainLayout() {
        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBorder(new EmptyBorder(8, 10, 8, 10));
        root.setBackground(COLOR_BG_MAIN);

        // 1. Thanh Header trên cùng
        root.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Khung chính chia đôi: Trái (5 Tab chức năng) - Phải (Màn hình Log giao thức SMTP/POP3)
        JSplitPane mainHorizontalSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        mainHorizontalSplit.setResizeWeight(0.66);

        mainTabs = new JTabbedPane();
        mainTabs.setFont(FONT_TAB);
        mainTabs.addTab("📥 1. Hộp thư đến (POP3 Inbox)", createInboxTab());
        mainTabs.addTab("✍️ 2. Soạn & Gửi Email / File (SMTP)", createComposeTab());
        mainTabs.addTab("📤 3. Hộp thư đã gửi (Sent)", createSentTab());
        mainTabs.addTab("🔍 4. Phân tích URL & InetAddress", createUrlInetTab());
        mainTabs.addTab("📄 5. Tài khoản & File data/" + currentUser.getUsername() + ".txt", createAccountDetailsTab());

        mainHorizontalSplit.setLeftComponent(mainTabs);
        mainHorizontalSplit.setRightComponent(createProtocolLogPanel());

        root.add(mainHorizontalSplit, BorderLayout.CENTER);
        setContentPane(root);
    }

    /**
     * Thanh Header hiển thị thông tin tài khoản đang đăng nhập và nút Đổi mật khẩu / Đăng xuất.
     */
    private JPanel createHeaderPanel() {
        JPanel topBanner = new JPanel(new BorderLayout(8, 4));
        topBanner.setBackground(COLOR_HEADER_BG);
        topBanner.setBorder(new EmptyBorder(8, 14, 8, 14));

        lblTopAccountBanner = new JLabel();
        lblTopAccountBanner.setForeground(Color.WHITE);
        lblTopAccountBanner.setFont(new Font("SansSerif", Font.BOLD, 12));
        updateTopBannerText();
        topBanner.add(lblTopAccountBanner, BorderLayout.CENTER);

        JPanel topRightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        topRightButtons.setOpaque(false);

        JButton btnChangePass = new JButton("🔒 Đổi mật khẩu");
        btnChangePass.addActionListener(e -> showChangePasswordDialog());

        JButton btnSwitchUser = new JButton("🚪 Đăng xuất / Đổi tài khoản");
        btnSwitchUser.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnSwitchUser.addActionListener(e -> handleLogout());

        topRightButtons.add(btnChangePass);
        topRightButtons.add(btnSwitchUser);
        topBanner.add(topRightButtons, BorderLayout.EAST);

        return topBanner;
    }

    /**
     * Khung bên phải: Màn hình hiển thị trực tiếp các lệnh giao thức mạng (C->S và S->C).
     */
    private JPanel createProtocolLogPanel() {
        JPanel protocolPanel = new JPanel(new BorderLayout(4, 4));
        protocolPanel.setBorder(new TitledBorder("📡 Nhật ký Giao thức mạng SMTP & POP3 (C->S / S->C trực tiếp trên GUI)"));
        protocolPanel.setBackground(Color.WHITE);

        txtProtocolConsole = new JTextArea();
        txtProtocolConsole.setEditable(false);
        txtProtocolConsole.setBackground(COLOR_CONSOLE_BG);
        txtProtocolConsole.setForeground(COLOR_CONSOLE_TEXT);
        txtProtocolConsole.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtProtocolConsole.setMargin(new Insets(8, 8, 8, 8));

        JPanel protoBottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 2));
        JButton btnClearLog = new JButton("🧹 Xóa màn hình Log");
        btnClearLog.addActionListener(e -> txtProtocolConsole.setText(""));
        protoBottomBar.add(btnClearLog);

        protocolPanel.add(new JScrollPane(txtProtocolConsole), BorderLayout.CENTER);
        protocolPanel.add(protoBottomBar, BorderLayout.SOUTH);
        return protocolPanel;
    }

    private void updateTopBannerText() {
        String localIp = "127.0.0.1";
        try {
            InetAddress local = InetAddress.getLocalHost();
            localIp = local.getHostName() + " (" + local.getHostAddress() + ")";
        } catch (Exception ignored) {
        }
        lblTopAccountBanner.setText(String.format(
                "👤 User: %s   |   🕒 Tạo TK: %s   |   🔑 Đăng nhập: %s   |   📁 File riêng: data/%s.txt   |   💻 Máy: %s",
                currentUser.getUsername(), currentUser.getCreatedAt(),
                currentUser.getLastLogin(), currentUser.getUsername(), localIp
        ));
    }

    // =========================================================================
    // TAB 1: HỘP THƯ ĐẾN (POP3 CLIENT - INBOX)
    // =========================================================================
    private JPanel createInboxTab() {
        JPanel panel = new JPanel(new BorderLayout(6, 6));
        panel.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel topActions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnFetchPop3 = new JButton("🔄 Nhận thư mới (Chạy giao thức POP3)");
        btnFetchPop3.setBackground(COLOR_PRIMARY_BTN);
        btnFetchPop3.setForeground(Color.WHITE);
        btnFetchPop3.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnFetchPop3.addActionListener(e -> runPop3FetchOnGui());

        JButton btnReply = new JButton("↩ Trả lời thư đang chọn");
        btnReply.addActionListener(e -> replySelectedInboxEmail());

        JButton btnDeletePop3 = new JButton("🗑 Xóa thư (POP3 DELE)");
        btnDeletePop3.addActionListener(e -> deleteSelectedInboxEmail());

        JButton btnSocketPop3 = new JButton("🔌 Test POP3 qua Socket Server");
        btnSocketPop3.setToolTipText("Kết nối qua Socket tới POP3 Server (localhost:1110 hoặc Server có sẵn)");
        btnSocketPop3.addActionListener(e -> showExternalPop3Dialog());

        topActions.add(btnFetchPop3);
        topActions.add(btnReply);
        topActions.add(btnDeletePop3);
        topActions.add(btnSocketPop3);
        panel.add(topActions, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.48);

        modelInbox = new DefaultTableModel(
                new String[]{"STT", "Thời gian gửi", "Người gửi (From)", "Người nhận (To)", "Tiêu đề (Subject)", "Tệp đính kèm"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tblInbox = new JTable(modelInbox);
        tblInbox.setRowHeight(25);
        tblInbox.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                displaySelectedInboxEmail();
            }
        });

        JPanel pnlDetail = new JPanel(new BorderLayout(4, 4));
        pnlDetail.setBorder(new TitledBorder("📖 Chi tiết nội dung Email trong Hộp thư đến (POP3 RETR)"));
        txtInboxDetail = new JTextArea("Chọn một email trong bảng phía trên để xem chi tiết nội dung và tệp đính kèm...");
        txtInboxDetail.setEditable(false);
        txtInboxDetail.setFont(FONT_MONO);
        txtInboxDetail.setLineWrap(true);
        txtInboxDetail.setWrapStyleWord(true);
        pnlDetail.add(new JScrollPane(txtInboxDetail), BorderLayout.CENTER);

        split.setTopComponent(new JScrollPane(tblInbox));
        split.setBottomComponent(pnlDetail);
        panel.add(split, BorderLayout.CENTER);

        return panel;
    }

    // =========================================================================
    // TAB 2: SOẠN & GỬI EMAIL / FILE (SMTP CLIENT)
    // =========================================================================
    private JPanel createComposeTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel topForm = new JPanel(new GridBagLayout());
        topForm.setBorder(new TitledBorder("Thông tin cấu hình & Người nhận (Giao thức SMTP)"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        cbSendMode = new JComboBox<>(new String[]{
                "Bản 1: Chạy trên Localhost (Cập nhật trực tiếp vào file data/<user>.txt)",
                "Bản 2: Kết nối vào Mail Server có sẵn qua Socket (SMTP Host/Port)"
        });
        cbSendMode.setFont(new Font("SansSerif", Font.BOLD, 12));

        pnlExternalSmtpConfig = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        pnlExternalSmtpConfig.setBackground(new Color(254, 249, 195));
        pnlExternalSmtpConfig.setBorder(BorderFactory.createLineBorder(new Color(250, 204, 21)));
        txtSmtpHost = new JTextField("127.0.0.1", 10);
        txtSmtpPort = new JTextField("2525", 5);
        txtSmtpAuthUser = new JTextField("", 8);
        txtSmtpAuthPass = new JPasswordField("", 8);
        pnlExternalSmtpConfig.add(new JLabel("SMTP Host:"));
        pnlExternalSmtpConfig.add(txtSmtpHost);
        pnlExternalSmtpConfig.add(new JLabel("Port:"));
        pnlExternalSmtpConfig.add(txtSmtpPort);
        pnlExternalSmtpConfig.add(new JLabel("Auth User (tùy chọn):"));
        pnlExternalSmtpConfig.add(txtSmtpAuthUser);
        pnlExternalSmtpConfig.add(new JLabel("Pass:"));
        pnlExternalSmtpConfig.add(txtSmtpAuthPass);
        pnlExternalSmtpConfig.setVisible(false);

        cbSendMode.addActionListener(e -> {
            pnlExternalSmtpConfig.setVisible(cbSendMode.getSelectedIndex() == 1);
            topForm.revalidate();
            topForm.repaint();
        });

        cbReceiver = new JComboBox<>();
        cbReceiver.setEditable(true);
        reloadRecipientSuggestions();

        JButton btnQuickNewReceiver = new JButton("➕ Tạo nhanh TK người nhận");
        btnQuickNewReceiver.setToolTipText("Tạo nhanh 1 tài khoản mới ngay trên GUI để test gửi thư");
        btnQuickNewReceiver.addActionListener(e -> quickCreateRecipientAccount());

        txtSubject = new JTextField("Báo cáo bài Lab Lập trình mạng - Nhóm 2 (VKU)");
        txtAttachment = new JTextField();
        JButton btnBrowseFile = new JButton("📎 Chọn File đính kèm...");
        btnBrowseFile.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn tệp đính kèm để gửi qua SMTP");
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File f = chooser.getSelectedFile();
                txtAttachment.setText(f.getName() + " (" + f.length() + " bytes - " + f.getAbsolutePath() + ")");
            }
        });

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        topForm.add(new JLabel("Chế độ hoạt động:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2; gbc.weightx = 1.0;
        topForm.add(cbSendMode, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 3;
        topForm.add(pnlExternalSmtpConfig, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; gbc.weightx = 0;
        topForm.add(new JLabel("Người nhận (Username):"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        topForm.add(cbReceiver, gbc);
        gbc.gridx = 2; gbc.gridy = 2; gbc.weightx = 0;
        topForm.add(btnQuickNewReceiver, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        topForm.add(new JLabel("Tiêu đề Email (Subject):"), gbc);
        gbc.gridx = 1; gbc.gridy = 3; gbc.gridwidth = 2; gbc.weightx = 1.0;
        topForm.add(txtSubject, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 1; gbc.weightx = 0;
        topForm.add(new JLabel("Tệp đính kèm (File):"), gbc);
        gbc.gridx = 1; gbc.gridy = 4; gbc.weightx = 1.0;
        topForm.add(txtAttachment, gbc);
        gbc.gridx = 2; gbc.gridy = 4; gbc.weightx = 0;
        topForm.add(btnBrowseFile, gbc);

        panel.add(topForm, BorderLayout.NORTH);

        JPanel bodyPanel = new JPanel(new BorderLayout(4, 4));
        bodyPanel.setBorder(new TitledBorder("Nội dung Email (Có thể chèn URL như http://vku.udn.vn để tự động phân tích URL)"));
        txtBody = new JTextArea(
                "Xin chào,\n\n"
                        + "Đây là email gửi từ chương trình SMTP Client (Java Swing GUI).\n"
                        + "Tham khảo tài liệu tại: http://vku.udn.vn/dao-tao?khoa=cntt#lich-hoc\n\n"
                        + "Trân trọng,\n" + currentUser.getUsername()
        );
        txtBody.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtBody.setLineWrap(true);
        txtBody.setWrapStyleWord(true);
        bodyPanel.add(new JScrollPane(txtBody), BorderLayout.CENTER);
        panel.add(bodyPanel, BorderLayout.CENTER);

        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        JButton btnClearCompose = new JButton("🧹 Xóa trắng form");
        btnClearCompose.addActionListener(e -> {
            txtSubject.setText("");
            txtBody.setText("");
            txtAttachment.setText("");
        });

        JButton btnSendSmtp = new JButton("🚀 GỬI EMAIL & FILE (THỰC THI GIAO THỨC SMTP)");
        btnSendSmtp.setBackground(COLOR_SUCCESS_BTN);
        btnSendSmtp.setForeground(Color.WHITE);
        btnSendSmtp.setFont(FONT_TAB);
        btnSendSmtp.addActionListener(e -> handleSendEmailOnGui());

        bottomBar.add(btnClearCompose);
        bottomBar.add(btnSendSmtp);
        panel.add(bottomBar, BorderLayout.SOUTH);

        return panel;
    }

    // =========================================================================
    // TAB 3: HỘP THƯ ĐÃ GỬI (SENT MAILBOX)
    // =========================================================================
    private JPanel createSentTab() {
        JPanel panel = new JPanel(new BorderLayout(6, 6));
        panel.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnRefreshSent = new JButton("🔄 Làm mới Hộp thư đã gửi");
        btnRefreshSent.addActionListener(e -> {
            currentUser = pop3Client.viewSentEmails(currentUser);
            appendProtocolLog(pop3Client.getLastProtocolLog());
            refreshAllMailAndFileViews();
        });

        JButton btnDeleteSent = new JButton("🗑 Xóa thư đã gửi đang chọn");
        btnDeleteSent.addActionListener(e -> deleteSelectedSentEmail());

        topBar.add(btnRefreshSent);
        topBar.add(btnDeleteSent);
        panel.add(topBar, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.48);

        modelSent = new DefaultTableModel(
                new String[]{"STT", "Thời gian gửi", "Người gửi (From)", "Gửi tới (To)", "Tiêu đề (Subject)", "Tệp đính kèm"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tblSent = new JTable(modelSent);
        tblSent.setRowHeight(25);
        tblSent.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                displaySelectedSentEmail();
            }
        });

        JPanel pnlDetail = new JPanel(new BorderLayout(4, 4));
        pnlDetail.setBorder(new TitledBorder("📖 Chi tiết Email đã gửi"));
        txtSentDetail = new JTextArea("Chọn một email trong danh sách thư đã gửi để xem nội dung chi tiết...");
        txtSentDetail.setEditable(false);
        txtSentDetail.setFont(FONT_MONO);
        txtSentDetail.setLineWrap(true);
        txtSentDetail.setWrapStyleWord(true);
        pnlDetail.add(new JScrollPane(txtSentDetail), BorderLayout.CENTER);

        split.setTopComponent(new JScrollPane(tblSent));
        split.setBottomComponent(pnlDetail);
        panel.add(split, BorderLayout.CENTER);

        return panel;
    }

    // =========================================================================
    // TAB 4: PHÂN TÍCH URL (diachi.java) & INETADDRESS (inet.java)
    // =========================================================================
    private JPanel createUrlInetTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel topBar = new JPanel(new BorderLayout(6, 4));
        txtNetInput = new JTextField("http://vku.udn.vn");
        txtNetInput.setFont(FONT_NORMAL);

        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        JButton btnAnalyze = new JButton("🔍 Phân tích URL & InetAddress");
        btnAnalyze.setBackground(COLOR_PRIMARY_BTN);
        btnAnalyze.setForeground(Color.WHITE);
        btnAnalyze.addActionListener(e -> runUrlAndInetAnalysis(txtNetInput.getText()));

        JButton btnSampleVku = new JButton("Mẫu vku.udn.vn");
        btnSampleVku.addActionListener(e -> {
            txtNetInput.setText("http://vku.udn.vn");
            runUrlAndInetAnalysis("http://vku.udn.vn");
        });

        JButton btnSampleTuoiTre = new JButton("Mẫu www.tuoitre.vn");
        btnSampleTuoiTre.addActionListener(e -> {
            txtNetInput.setText("https://www.tuoitre.vn");
            runUrlAndInetAnalysis("https://www.tuoitre.vn");
        });

        btnGroup.add(btnAnalyze);
        btnGroup.add(btnSampleVku);
        btnGroup.add(btnSampleTuoiTre);

        topBar.add(new JLabel("Nhập URL hoặc Tên miền Mail Server: "), BorderLayout.WEST);
        topBar.add(txtNetInput, BorderLayout.CENTER);
        topBar.add(btnGroup, BorderLayout.EAST);
        panel.add(topBar, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.52);

        JPanel leftTables = new JPanel(new GridLayout(2, 1, 6, 6));

        JPanel pnlUrl = new JPanel(new BorderLayout());
        pnlUrl.setBorder(new TitledBorder("1. Bảng phân tích java.net.URL (Bài mẫu diachi.java)"));
        modelUrlProps = new DefaultTableModel(new String[]{"Thuộc tính URL", "Giá trị trả về"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable tblUrl = new JTable(modelUrlProps);
        tblUrl.setRowHeight(23);
        pnlUrl.add(new JScrollPane(tblUrl), BorderLayout.CENTER);

        JPanel pnlInet = new JPanel(new BorderLayout());
        pnlInet.setBorder(new TitledBorder("2. Bảng phân giải java.net.InetAddress (Bài mẫu inet.java - LocalHost & getAllByName)"));
        modelInetProps = new DefaultTableModel(new String[]{"Hạng mục InetAddress", "Host Name / IP Address"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable tblInet = new JTable(modelInetProps);
        tblInet.setRowHeight(23);
        pnlInet.add(new JScrollPane(tblInet), BorderLayout.CENTER);

        leftTables.add(pnlUrl);
        leftTables.add(pnlInet);

        JPanel rightReport = new JPanel(new BorderLayout());
        rightReport.setBorder(new TitledBorder("Kết quả chi tiết chuẩn theo diachi.java & inet.java"));
        txtNetConsole = new JTextArea();
        txtNetConsole.setEditable(false);
        txtNetConsole.setFont(FONT_MONO);
        rightReport.add(new JScrollPane(txtNetConsole), BorderLayout.CENTER);

        split.setLeftComponent(leftTables);
        split.setRightComponent(rightReport);
        panel.add(split, BorderLayout.CENTER);

        SwingUtilities.invokeLater(() -> runUrlAndInetAnalysis("http://vku.udn.vn"));
        return panel;
    }

    // =========================================================================
    // TAB 5: THÔNG TIN TÀI KHOẢN CÁ NHÂN & XEM TRỰC TIẾP FILE data/<username>.txt
    // =========================================================================
    private JPanel createAccountDetailsTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel infoCard = new JPanel(new GridLayout(4, 2, 12, 8));
        infoCard.setBackground(Color.WHITE);
        infoCard.setBorder(BorderFactory.createCompoundBorder(
                new TitledBorder("📋 Thông tin chi tiết Tài khoản Cá nhân (Hiển thị trực tiếp trên GUI)"),
                new EmptyBorder(8, 14, 8, 14)
        ));

        lblAccUser = new JLabel();
        lblAccPass = new JLabel();
        lblAccCreated = new JLabel();
        lblAccLastLogin = new JLabel();
        lblAccFilePath = new JLabel();
        lblAccInboxCount = new JLabel();
        lblAccSentCount = new JLabel();

        lblAccUser.setFont(FONT_TAB);
        lblAccPass.setFont(FONT_TAB);
        lblAccCreated.setFont(FONT_TAB);
        lblAccLastLogin.setFont(FONT_TAB);
        lblAccFilePath.setFont(FONT_TAB);
        lblAccInboxCount.setFont(FONT_TAB);
        lblAccSentCount.setFont(FONT_TAB);

        infoCard.add(lblAccUser);
        infoCard.add(lblAccPass);
        infoCard.add(lblAccCreated);
        infoCard.add(lblAccLastLogin);
        infoCard.add(lblAccFilePath);
        infoCard.add(lblAccInboxCount);
        infoCard.add(lblAccSentCount);

        JButton btnRefreshFile = new JButton("🔄 Đồng bộ & Xem mới nhất từ File .txt");
        btnRefreshFile.addActionListener(e -> refreshAllMailAndFileViews());
        infoCard.add(btnRefreshFile);

        panel.add(infoCard, BorderLayout.NORTH);

        JPanel rawFilePanel = new JPanel(new BorderLayout(4, 4));
        rawFilePanel.setBorder(new TitledBorder(
                "📄 Nội dung thực tế trong File riêng của tài khoản (data/" + currentUser.getUsername()
                        + ".txt - Lưu chung [ACCOUNT], [INBOX], [SENT])"
        ));
        txtRawAccountFile = new JTextArea();
        txtRawAccountFile.setEditable(false);
        txtRawAccountFile.setFont(FONT_MONO);
        rawFilePanel.add(new JScrollPane(txtRawAccountFile), BorderLayout.CENTER);

        panel.add(rawFilePanel, BorderLayout.CENTER);
        return panel;
    }

    // =========================================================================
    // 4. CÁC HÀM XỬ LÝ SỰ KIỆN NÚT BẤM TRÊN GUI
    // =========================================================================
    private void runPop3FetchOnGui() {
        currentUser = pop3Client.fetchEmails(currentUser);
        appendProtocolLog(pop3Client.getLastProtocolLog());
        refreshAllMailAndFileViews();
        if (!currentUser.getInbox().isEmpty()) {
            tblInbox.setRowSelectionInterval(0, 0);
            displaySelectedInboxEmail();
        }
    }

    private void handleSendEmailOnGui() {
        Object recvObj = cbReceiver.getSelectedItem();
        String toUser = recvObj == null ? "" : recvObj.toString().trim();
        String subject = txtSubject.getText().trim();
        String body = txtBody.getText().trim();
        String attachment = txtAttachment.getText().trim();

        if (toUser.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập hoặc chọn Tên tài khoản người nhận!",
                    "Thiếu người nhận", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (subject.isEmpty()) {
            subject = "(Không có tiêu đề)";
        }

        boolean ok;
        if (cbSendMode.getSelectedIndex() == 0) {
            ok = smtpClient.sendEmail(currentUser, toUser, subject, body, attachment);
        } else {
            String host = txtSmtpHost.getText().trim();
            int port = 2525;
            try {
                port = Integer.parseInt(txtSmtpPort.getText().trim());
            } catch (NumberFormatException ignored) {
            }
            String authU = txtSmtpAuthUser.getText().trim();
            String authP = new String(txtSmtpAuthPass.getPassword()).trim();
            ok = smtpClient.sendEmailViaExternalServer(
                    currentUser, host, port, authU, authP, toUser, subject, body, attachment
            );
        }

        appendProtocolLog(smtpClient.getLastProtocolLog());
        refreshAllMailAndFileViews();

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    smtpClient.getLastStatusMessage()
                            + "\nToàn bộ thông tin Email & File đã được cập nhật vào file .txt của tài khoản!",
                    "SMTP Thành công", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    smtpClient.getLastStatusMessage(),
                    "SMTP Thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displaySelectedInboxEmail() {
        int row = tblInbox.getSelectedRow();
        if (row < 0 || row >= currentUser.getInbox().size()) return;
        Email e = currentUser.getInbox().get(row);
        txtInboxDetail.setText(formatEmailDetailText(e, row + 1, "HỘP THƯ ĐẾN (POP3 RETR #" + (row + 1) + ")"));
        txtInboxDetail.setCaretPosition(0);
    }

    private void displaySelectedSentEmail() {
        int row = tblSent.getSelectedRow();
        if (row < 0 || row >= currentUser.getSent().size()) return;
        Email e = currentUser.getSent().get(row);
        txtSentDetail.setText(formatEmailDetailText(e, row + 1, "HỘP THƯ ĐÃ GỬI (SENT #" + (row + 1) + ")"));
        txtSentDetail.setCaretPosition(0);
    }

    private String formatEmailDetailText(Email e, int stt, String boxTitle) {
        StringBuilder sb = new StringBuilder();
        sb.append("================ ").append(boxTitle).append(" ================\n");
        sb.append("STT           : #").append(stt).append("\n");
        sb.append("Thời gian gửi : ").append(e.getTime()).append("\n");
        sb.append("Người gửi     : ").append(e.getSender()).append("\n");
        sb.append("Người nhận    : ").append(e.getReceiver()).append("\n");
        sb.append("Tiêu đề       : ").append(e.getSubject()).append("\n");
        sb.append("Tệp đính kèm  : ").append(e.getAttachedFile()).append("\n");
        sb.append("------------------------------------------------------------\n");
        sb.append("NỘI DUNG EMAIL:\n\n").append(e.getBody()).append("\n");
        return sb.toString();
    }

    private void replySelectedInboxEmail() {
        int row = tblInbox.getSelectedRow();
        if (row < 0 || row >= currentUser.getInbox().size()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn 1 thư trong Hộp thư đến để trả lời!");
            return;
        }
        Email e = currentUser.getInbox().get(row);
        cbReceiver.setSelectedItem(e.getSender());
        txtSubject.setText(e.getSubject().startsWith("Re:") ? e.getSubject() : "Re: " + e.getSubject());
        txtBody.setText("\n\n--- Thư gốc từ " + e.getSender() + " lúc " + e.getTime() + " ---\n" + e.getBody());
        mainTabs.setSelectedIndex(1);
    }

    private void deleteSelectedInboxEmail() {
        int row = tblInbox.getSelectedRow();
        if (row < 0 || row >= currentUser.getInbox().size()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn 1 thư trong Hộp thư đến để xóa!");
            return;
        }
        if (pop3Client.deleteEmailPop3(currentUser, row)) {
            appendProtocolLog(pop3Client.getLastProtocolLog());
            txtInboxDetail.setText("Đã xóa thư #" + (row + 1) + " và cập nhật trực tiếp vào data/" + currentUser.getUsername() + ".txt.");
            refreshAllMailAndFileViews();
        }
    }

    private void deleteSelectedSentEmail() {
        int row = tblSent.getSelectedRow();
        if (row < 0 || row >= currentUser.getSent().size()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn 1 thư đã gửi để xóa!");
            return;
        }
        try {
            currentUser.getSent().remove(row);
            fileManager.saveAccount(currentUser);
            txtSentDetail.setText("Đã xóa thư đã gửi #" + (row + 1) + " và cập nhật vào data/" + currentUser.getUsername() + ".txt.");
            refreshAllMailAndFileViews();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật file: " + ex.getMessage());
        }
    }

    private void showExternalPop3Dialog() {
        JTextField txtHost = new JTextField("127.0.0.1", 14);
        JTextField txtPort = new JTextField("1110", 6);
        JTextField txtUser = new JTextField(currentUser.getUsername(), 14);
        JPasswordField txtPass = new JPasswordField(currentUser.getPassword(), 14);

        JPanel p = new JPanel(new GridLayout(4, 2, 6, 6));
        p.add(new JLabel("POP3 Server Host:"));
        p.add(txtHost);
        p.add(new JLabel("POP3 Server Port:"));
        p.add(txtPort);
        p.add(new JLabel("POP3 Username:"));
        p.add(txtUser);
        p.add(new JLabel("POP3 Password:"));
        p.add(txtPass);

        if (JOptionPane.showConfirmDialog(this, p, "Kết nối POP3 Server có sẵn qua Socket",
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            int port = 1110;
            try {
                port = Integer.parseInt(txtPort.getText().trim());
            } catch (NumberFormatException ignored) {
            }
            boolean ok = pop3Client.fetchFromExternalPop3Server(
                    currentUser, txtHost.getText().trim(), port,
                    txtUser.getText().trim(), new String(txtPass.getPassword()).trim()
            );
            appendProtocolLog(pop3Client.getLastProtocolLog());
            refreshAllMailAndFileViews();
            if (ok) {
                JOptionPane.showMessageDialog(this, "Đã thực hiện phiên POP3 qua Socket thành công! Xem chi tiết ở khung Log bên phải.");
            } else {
                JOptionPane.showMessageDialog(this, "Không thể kết nối tới POP3 Server: Xem chi tiết ở khung Log bên phải.",
                        "Lỗi kết nối POP3", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void quickCreateRecipientAccount() {
        JTextField txtNewU = new JTextField(14);
        JPasswordField txtNewP = new JPasswordField("123456", 14);
        JPanel p = new JPanel(new GridLayout(2, 2, 6, 6));
        p.add(new JLabel("Username người nhận mới:"));
        p.add(txtNewU);
        p.add(new JLabel("Mật khẩu khởi tạo:"));
        p.add(txtNewP);

        if (JOptionPane.showConfirmDialog(this, p, "Tạo nhanh tài khoản người nhận",
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            String u = txtNewU.getText().trim();
            String pw = new String(txtNewP.getPassword()).trim();
            if (u.isEmpty() || pw.isEmpty()) return;
            try {
                if (fileManager.createAccount(u, pw)) {
                    reloadRecipientSuggestions();
                    cbReceiver.setSelectedItem(u);
                    JOptionPane.showMessageDialog(this,
                            "Đã tạo tài khoản '" + u + "' kèm file riêng data/" + u + ".txt!");
                } else {
                    JOptionPane.showMessageDialog(this, "Tài khoản '" + u + "' đã tồn tại!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
            }
        }
    }

    private void reloadRecipientSuggestions() {
        Object current = cbReceiver.getSelectedItem();
        cbReceiver.removeAllItems();
        for (String u : fileManager.listAllUsernames()) {
            cbReceiver.addItem(u);
        }
        if (current != null) {
            cbReceiver.setSelectedItem(current);
        } else if (cbReceiver.getItemCount() > 0) {
            for (int i = 0; i < cbReceiver.getItemCount(); i++) {
                String item = cbReceiver.getItemAt(i);
                if (!item.equalsIgnoreCase(currentUser.getUsername())) {
                    cbReceiver.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void runUrlAndInetAnalysis(String rawInput) {
        modelUrlProps.setRowCount(0);
        modelInetProps.setRowCount(0);
        StringBuilder report = new StringBuilder();

        String input = rawInput == null ? "" : rawInput.trim();
        String urlCandidate = input.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? input : "http://" + input;

        report.append("================ 1. PHÂN TÍCH URL (Bài mẫu diachi.java) ================\n");
        String host = input;
        try {
            URL url = new URL(urlCandidate);
            host = url.getHost();
            addUrlRow("URL (url.toString())", url.toString(), report);
            addUrlRow("protocol", url.getProtocol(), report);
            addUrlRow("authority", url.getAuthority(), report);
            addUrlRow("file name", url.getFile(), report);
            addUrlRow("host", url.getHost(), report);
            addUrlRow("path", url.getPath(), report);
            addUrlRow("port", String.valueOf(url.getPort()), report);
            addUrlRow("default port", String.valueOf(url.getDefaultPort()), report);
            addUrlRow("query", String.valueOf(url.getQuery()), report);
            addUrlRow("ref", String.valueOf(url.getRef()), report);
        } catch (Exception e) {
            modelUrlProps.addRow(new Object[]{"Lỗi phân tích URL", e.getMessage()});
            report.append("Lỗi URL: ").append(e.getMessage()).append("\n");
        }

        report.append("\n============= 2. PHÂN TÍCH INETADDRESS (Bài mẫu inet.java) =============\n");
        try {
            InetAddress local = InetAddress.getLocalHost();
            modelInetProps.addRow(new Object[]{"LocalHost Name", local.getHostName()});
            modelInetProps.addRow(new Object[]{"LocalHost IP Address", local.getHostAddress()});
            report.append("Host Name (LocalHost): ").append(local.getHostName()).append("\n");
            report.append("IP Address (LocalHost): ").append(local.getHostAddress()).append("\n\n");

            if (host == null || host.isEmpty()) host = "vku.udn.vn";
            InetAddress target = InetAddress.getByName(host);
            modelInetProps.addRow(new Object[]{"Host Name (" + host + ")", target.getHostName()});
            modelInetProps.addRow(new Object[]{"IP Address (" + host + ")", target.getHostAddress()});
            report.append("Host Name: ").append(target.getHostName()).append("\n");
            report.append("IP Address: ").append(target.getHostAddress()).append("\n\n");

            report.append("All address of ").append(host).append(":\n");
            InetAddress[] sw = InetAddress.getAllByName(host);
            for (int i = 0; i < sw.length; i++) {
                modelInetProps.addRow(new Object[]{"getAllByName [" + (i + 1) + "]", sw[i].toString()});
                report.append("  ").append(sw[i].toString()).append("\n");
            }
        } catch (Exception e) {
            modelInetProps.addRow(new Object[]{"Lỗi phân giải DNS", e.getMessage()});
            report.append("Lỗi InetAddress: ").append(e.getMessage()).append("\n");
        }

        txtNetConsole.setText(report.toString());
        txtNetConsole.setCaretPosition(0);
    }

    private void addUrlRow(String key, String val, StringBuilder report) {
        modelUrlProps.addRow(new Object[]{key, val});
        report.append(String.format("%-16s : %s\n", key, val));
    }

    private void refreshAllMailAndFileViews() {
        try {
            Account latest = fileManager.loadAccount(currentUser.getUsername());
            if (latest != null) {
                currentUser = latest;
            }
        } catch (Exception ignored) {
        }

        updateTopBannerText();
        reloadRecipientSuggestions();

        modelInbox.setRowCount(0);
        List<Email> inbox = currentUser.getInbox();
        for (int i = 0; i < inbox.size(); i++) {
            Email e = inbox.get(i);
            modelInbox.addRow(new Object[]{
                    "#" + (i + 1), e.getTime(), e.getSender(), e.getReceiver(), e.getSubject(), e.getAttachedFile()
            });
        }

        modelSent.setRowCount(0);
        List<Email> sent = currentUser.getSent();
        for (int i = 0; i < sent.size(); i++) {
            Email e = sent.get(i);
            modelSent.addRow(new Object[]{
                    "#" + (i + 1), e.getTime(), e.getSender(), e.getReceiver(), e.getSubject(), e.getAttachedFile()
            });
        }

        lblAccUser.setText("👤 Tên đăng nhập: " + currentUser.getUsername());
        lblAccPass.setText("🔑 Mật khẩu: " + currentUser.getPassword());
        lblAccCreated.setText("🕒 Thời gian tạo TK: " + currentUser.getCreatedAt());
        lblAccLastLogin.setText("🔓 Đăng nhập lần cuối: " + currentUser.getLastLogin());
        lblAccFilePath.setText("📁 Đường dẫn File riêng: data/" + currentUser.getUsername() + ".txt");
        lblAccInboxCount.setText("📥 Tổng thư trong Inbox: " + currentUser.getInbox().size() + " thư");
        lblAccSentCount.setText("📤 Tổng thư đã gửi (Sent): " + currentUser.getSent().size() + " thư");

        txtRawAccountFile.setText(fileManager.readRawAccountFile(currentUser.getUsername()));
        txtRawAccountFile.setCaretPosition(0);
    }

    private void appendProtocolLog(String logBlock) {
        if (logBlock == null || logBlock.isEmpty()) return;
        txtProtocolConsole.append(logBlock + "\n");
        txtProtocolConsole.setCaretPosition(txtProtocolConsole.getDocument().getLength());
    }

    private void showChangePasswordDialog() {
        JPasswordField txtNewPass = new JPasswordField(currentUser.getPassword(), 16);
        JPanel p = new JPanel(new GridLayout(1, 2, 6, 6));
        p.add(new JLabel("Nhập mật khẩu mới:"));
        p.add(txtNewPass);

        if (JOptionPane.showConfirmDialog(this, p, "Đổi mật khẩu tài khoản " + currentUser.getUsername(),
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            String newPass = new String(txtNewPass.getPassword()).trim();
            if (!newPass.isEmpty()) {
                try {
                    currentUser.setPassword(newPass);
                    fileManager.saveAccount(currentUser);
                    refreshAllMailAndFileViews();
                    JOptionPane.showMessageDialog(this,
                            "Đã cập nhật mật khẩu trực tiếp vào file data/" + currentUser.getUsername() + ".txt!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi lưu file: " + ex.getMessage());
                }
            }
        }
    }

    private void handleLogout() {
        dispose();
        launch(fileManager);
    }

    // =========================================================================
    // 5. HỘP THOẠI ĐĂNG NHẬP & ĐĂNG KÝ (AUTH DIALOG)
    // =========================================================================
    public static class AuthDialog extends JDialog {
        private final FileManager fm;
        private Account authenticatedAccount;

        public AuthDialog(FileManager fm) {
            super((JFrame) null, "Đăng nhập / Đăng ký - Cổng Giao Thức Mail Client (Nhóm 2)", true);
            this.fm = fm;
            setSize(540, 430);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            buildUi();
        }

        private void buildUi() {
            JPanel root = new JPanel(new BorderLayout(10, 10));
            root.setBorder(new EmptyBorder(14, 18, 14, 18));
            root.setBackground(new Color(248, 250, 252));

            JLabel lblTitle = new JLabel("NHÓM 2: CỔNG GIAO THỨC SMTP & POP3 MAIL CLIENT", SwingConstants.CENTER);
            lblTitle.setFont(FONT_TITLE);
            lblTitle.setForeground(COLOR_PRIMARY_BTN);
            root.add(lblTitle, BorderLayout.NORTH);

            JTabbedPane tabs = new JTabbedPane();

            // Tab Đăng nhập
            JPanel loginPanel = new JPanel(new GridBagLayout());
            loginPanel.setBackground(Color.WHITE);
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(8, 8, 8, 8);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JComboBox<String> cbUsers = new JComboBox<>();
            cbUsers.setEditable(true);
            for (String u : fm.listAllUsernames()) {
                cbUsers.addItem(u);
            }
            if (cbUsers.getItemCount() > 0) {
                cbUsers.setSelectedIndex(0);
            }
            JPasswordField txtPass = new JPasswordField("123456", 18);

            gbc.gridx = 0; gbc.gridy = 0;
            loginPanel.add(new JLabel("Username:"), gbc);
            gbc.gridx = 1;
            loginPanel.add(cbUsers, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            loginPanel.add(new JLabel("Password:"), gbc);
            gbc.gridx = 1;
            loginPanel.add(txtPass, gbc);

            JButton btnLogin = new JButton("🔑 Đăng nhập Hệ thống Mail");
            btnLogin.setBackground(COLOR_PRIMARY_BTN);
            btnLogin.setForeground(Color.WHITE);
            btnLogin.setFont(FONT_TAB);
            gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
            loginPanel.add(btnLogin, gbc);

            JLabel lblHint = new JLabel(
                    "<html><i>Tài khoản mẫu có sẵn: <b>alice / 123456</b> (<code>data/alice.txt</code>) "
                            + "và <b>bob / 123456</b> (<code>data/bob.txt</code>)</i></html>"
            );
            gbc.gridy = 3;
            loginPanel.add(lblHint, gbc);

            btnLogin.addActionListener(e -> {
                Object uObj = cbUsers.getSelectedItem();
                String user = uObj == null ? "" : uObj.toString().trim();
                String pass = new String(txtPass.getPassword()).trim();
                try {
                    Account acc = fm.loadAccount(user);
                    if (acc != null && acc.getPassword().equals(pass)) {
                        acc.setLastLogin(FileManager.getCurrentTime());
                        fm.saveAccount(acc);
                        authenticatedAccount = acc;
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this,
                                "Đăng nhập thất bại: Sai Username hoặc Password!",
                                "Lỗi xác thực", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi hệ thống: " + ex.getMessage());
                }
            });

            // Tab Đăng ký
            JPanel regPanel = new JPanel(new GridBagLayout());
            regPanel.setBackground(Color.WHITE);
            GridBagConstraints rg = new GridBagConstraints();
            rg.insets = new Insets(8, 8, 8, 8);
            rg.fill = GridBagConstraints.HORIZONTAL;

            JTextField txtRegUser = new JTextField(18);
            JPasswordField txtRegPass = new JPasswordField(18);

            rg.gridx = 0; rg.gridy = 0;
            regPanel.add(new JLabel("Username mới:"), rg);
            rg.gridx = 1;
            regPanel.add(txtRegUser, rg);

            rg.gridx = 0; rg.gridy = 1;
            regPanel.add(new JLabel("Password:"), rg);
            rg.gridx = 1;
            regPanel.add(txtRegPass, rg);

            JButton btnReg = new JButton("📝 Đăng ký & Khởi tạo File data/<username>.txt");
            btnReg.setBackground(COLOR_SUCCESS_BTN);
            btnReg.setForeground(Color.WHITE);
            btnReg.setFont(FONT_TAB);
            rg.gridx = 0; rg.gridy = 2; rg.gridwidth = 2;
            regPanel.add(btnReg, rg);

            btnReg.addActionListener(e -> {
                String user = txtRegUser.getText().trim();
                String pass = new String(txtRegPass.getPassword()).trim();
                if (user.isEmpty() || pass.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Username và Password không được để trống!");
                    return;
                }
                try {
                    if (fm.createAccount(user, pass)) {
                        JOptionPane.showMessageDialog(this,
                                "Đăng ký thành công!\nĐã khởi tạo file dữ liệu cá nhân: data/" + user + ".txt\n"
                                        + "Hệ thống sẽ tự động đăng nhập.");
                        authenticatedAccount = fm.loadAccount(user);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this,
                                "Đăng ký thất bại: Tài khoản '" + user + "' đã tồn tại!",
                                "Trùng tài khoản", JOptionPane.WARNING_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
                }
            });

            tabs.addTab("🔑 Đăng nhập (Login)", loginPanel);
            tabs.addTab("📝 Đăng ký (Register)", regPanel);
            root.add(tabs, BorderLayout.CENTER);

            String localHostStr = "localhost (127.0.0.1)";
            try {
                InetAddress local = InetAddress.getLocalHost();
                localHostStr = local.getHostName() + " (" + local.getHostAddress() + ")";
            } catch (Exception ignored) {
            }
            JLabel lblFooter = new JLabel(
                    "Máy trạm (InetAddress): " + localHostStr + " | Mỗi tài khoản lưu chung trong 1 file data/<username>.txt",
                    SwingConstants.CENTER
            );
            lblFooter.setFont(new Font("SansSerif", Font.ITALIC, 11));
            root.add(lblFooter, BorderLayout.SOUTH);

            setContentPane(root);
        }

        public Account getAuthenticatedAccount() {
            return authenticatedAccount;
        }
    }

    /**
     * Hàm tiện ích khởi chạy hộp thoại Đăng nhập và mở cửa sổ chính MailClientGUI.
     */
    public static void launch(FileManager fileManager) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        SwingUtilities.invokeLater(() -> {
            AuthDialog auth = new AuthDialog(fileManager);
            auth.setVisible(true);
            if (auth.getAuthenticatedAccount() != null) {
                MailClientGUI gui = new MailClientGUI(fileManager, auth.getAuthenticatedAccount());
                gui.setVisible(true);
            } else {
                System.exit(0);
            }
        });
    }
}