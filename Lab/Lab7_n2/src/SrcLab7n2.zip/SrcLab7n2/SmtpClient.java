package protocol;

import model.Account;
import model.Email;
import storage.FileManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Xử lý giao thức truyền tin đơn giản SMTP (Simple Mail Transfer Protocol).
 * Toàn bộ nhật ký lệnh giao thức (C->S và S->C) được trả về cho giao diện Java Swing GUI
 * thay vì chỉ in ra Terminal, đồng thời hỗ trợ:
 * 1. Gửi nội bộ trên Localhost (cập nhật trực tiếp vào file data/<sender>.txt và data/<receiver>.txt)
 * 2. Kết nối qua Socket tới Mail Server có sẵn (hMailServer, James, Mailtrap, hoặc SMTP Server bất kỳ)
 * 3. Tích hợp java.net.InetAddress (inet.java) và java.net.URL (diachi.java) để kiểm tra Host/URL trong thư.
 */
public class SmtpClient {
    private final FileManager fileManager;
    private String lastProtocolLog = "";
    private String lastStatusMessage = "";

    public SmtpClient() {
        this.fileManager = new FileManager();
    }

    public String getLastProtocolLog() {
        return lastProtocolLog;
    }

    public String getLastStatusMessage() {
        return lastStatusMessage;
    }

    /**
     * Bản 1: Gửi Email nội bộ trên Localhost và cập nhật đồng thời vào file .txt riêng của Người gửi & Người nhận.
     */
    public boolean sendEmail(Account senderAcc, String receiverUsername, String subject, String body, String attachedFile) {
        StringBuilder log = new StringBuilder();
        String safeFile = (attachedFile == null || attachedFile.trim().isEmpty()) ? "None" : attachedFile.trim();

        log.append("==========================================================\n");
        log.append("   PHIÊN LÀM VIỆC GIAO THỨC SMTP CLIENT (LOCALHOST MODE)\n");
        log.append("==========================================================\n");

        // Áp dụng InetAddress (bài mẫu inet.java) kiểm tra máy cục bộ
        try {
            InetAddress local = InetAddress.getLocalHost();
            log.append("[InetAddress] Client HostName : ").append(local.getHostName()).append("\n");
            log.append("[InetAddress] Client IP       : ").append(local.getHostAddress()).append("\n");
        } catch (Exception ignored) {
        }

        // Áp dụng URL (bài mẫu diachi.java) nếu trong nội dung thư có chứa đường link URL
        appendUrlAnalysisIfPresent(body, log);

        log.append("C->S: HELO smtp.vku.udn.vn\n");
        log.append("S->C: 250 Hello smtp.vku.udn.vn (127.0.0.1), pleased to meet you\n");

        log.append("C->S: MAIL FROM:<").append(senderAcc.getUsername()).append("@vku.udn.vn>\n");
        log.append("S->C: 250 2.1.0 Sender OK\n");

        log.append("C->S: RCPT TO:<").append(receiverUsername).append("@vku.udn.vn>\n");

        if (!fileManager.userExists(receiverUsername)) {
            log.append("S->C: 550 5.1.1 User unknown / Account file data/").append(receiverUsername).append(".txt does not exist\n");
            log.append("===> THẤT BẠI: Tài khoản người nhận '").append(receiverUsername).append("' chưa tồn tại trên hệ thống!\n");
            this.lastProtocolLog = log.toString();
            this.lastStatusMessage = "Người nhận '" + receiverUsername + "' không tồn tại (chưa có file data/" + receiverUsername + ".txt)!";
            return false;
        }

        log.append("S->C: 250 2.1.5 Recipient OK\n");
        log.append("C->S: DATA\n");
        log.append("S->C: 354 Start mail input; end with <CRLF>.<CRLF>\n");
        log.append("C->S: From: ").append(senderAcc.getUsername()).append("@vku.udn.vn\n");
        log.append("C->S: To: ").append(receiverUsername).append("@vku.udn.vn\n");
        log.append("C->S: Subject: ").append(subject).append("\n");
        log.append("C->S: Content: ").append(body).append("\n");
        log.append("C->S: Attachment: ").append(safeFile).append("\n");
        log.append("C->S: .\n");

        try {
            String currentTime = FileManager.getCurrentTime();
            Email email = new Email(currentTime, senderAcc.getUsername(), receiverUsername, subject, body, safeFile);

            // 1. Nếu gửi cho chính mình thì cả SENT và INBOX đều nằm trên cùng 1 đối tượng Account
            if (senderAcc.getUsername().equalsIgnoreCase(receiverUsername)) {
                senderAcc.getSent().add(email);
                senderAcc.getInbox().add(email);
                fileManager.saveAccount(senderAcc);
            } else {
                // Cập nhật danh sách SENT của Sender và ghi đè file data/<sender>.txt
                senderAcc.getSent().add(email);
                fileManager.saveAccount(senderAcc);

                // Load Account Receiver, thêm vào INBOX và ghi đè file data/<receiver>.txt
                Account receiverAcc = fileManager.loadAccount(receiverUsername);
                receiverAcc.getInbox().add(email);
                fileManager.saveAccount(receiverAcc);
            }

            log.append("S->C: 250 2.0.0 Message accepted for delivery (Updated data/")
                    .append(senderAcc.getUsername()).append(".txt & data/").append(receiverUsername).append(".txt)\n");
            log.append("C->S: QUIT\n");
            log.append("S->C: 221 2.0.0 Service closing transmission channel\n");
            log.append("===> THÀNH CÔNG: Đã gửi email và cập nhật trực tiếp vào file .txt của 2 tài khoản!\n");

            this.lastProtocolLog = log.toString();
            this.lastStatusMessage = "Đã gửi email thành công tới '" + receiverUsername + "'!";
            return true;
        } catch (Exception e) {
            log.append("S->C: 451 Requested action aborted: local error in processing\n");
            log.append("===> LỖI: ").append(e.getMessage()).append("\n");
            this.lastProtocolLog = log.toString();
            this.lastStatusMessage = "Lỗi khi lưu file dữ liệu: " + e.getMessage();
            return false;
        }
    }

    /**
     * Bản 2: Kết nối qua Socket tới Mail Server SMTP có sẵn (VD: hMailServer, Apache James, Mailtrap...)
     * và vẫn lưu lịch sử thư đã gửi vào file data/<sender>.txt của tài khoản.
     */
    public boolean sendEmailViaExternalServer(Account senderAcc, String smtpHost, int smtpPort,
                                              String authUser, String authPass,
                                              String receiverEmail, String subject, String body, String attachedFile) {
        StringBuilder log = new StringBuilder();
        String safeFile = (attachedFile == null || attachedFile.trim().isEmpty()) ? "None" : attachedFile.trim();

        log.append("==========================================================\n");
        log.append("   SMTP CLIENT KẾT NỐI MAIL SERVER CÓ SẴN QUA SOCKET\n");
        log.append("==========================================================\n");

        try {
            // Phân giải InetAddress của Mail Server (áp dụng bài mẫu inet.java)
            InetAddress serverAddr = InetAddress.getByName(smtpHost);
            log.append("[InetAddress] SMTP Server Host : ").append(serverAddr.getHostName()).append("\n");
            log.append("[InetAddress] SMTP Server IP   : ").append(serverAddr.getHostAddress()).append("\n");
            InetAddress[] allIps = InetAddress.getAllByName(smtpHost);
            for (int i = 0; i < allIps.length; i++) {
                log.append("  -> Server IP [").append(i + 1).append("]: ").append(allIps[i].toString()).append("\n");
            }
        } catch (Exception ex) {
            log.append("[InetAddress] Cảnh báo phân giải DNS: ").append(ex.getMessage()).append("\n");
        }

        appendUrlAnalysisIfPresent(body, log);

        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(smtpHost, smtpPort), 5000);
            socket.setSoTimeout(7000);

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter writer = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

            String greeting = reader.readLine();
            log.append("S->C: ").append(greeting).append("\n");

            sendCmd(writer, reader, log, "EHLO vku.udn.vn");

            if (authUser != null && !authUser.trim().isEmpty()) {
                sendCmd(writer, reader, log, "AUTH LOGIN");
                sendCmd(writer, reader, log, Base64.getEncoder().encodeToString(authUser.trim().getBytes(StandardCharsets.UTF_8)));
                sendCmd(writer, reader, log, Base64.getEncoder().encodeToString((authPass == null ? "" : authPass).getBytes(StandardCharsets.UTF_8)));
            }

            String fromAddr = senderAcc.getUsername().contains("@")
                    ? senderAcc.getUsername()
                    : senderAcc.getUsername() + "@vku.udn.vn";
            String toAddr = receiverEmail.contains("@")
                    ? receiverEmail
                    : receiverEmail + "@vku.udn.vn";

            sendCmd(writer, reader, log, "MAIL FROM:<" + fromAddr + ">");
            sendCmd(writer, reader, log, "RCPT TO:<" + toAddr + ">");
            sendCmd(writer, reader, log, "DATA");

            writer.print("From: " + fromAddr + "\r\n");
            writer.print("To: " + toAddr + "\r\n");
            writer.print("Subject: " + subject + "\r\n");
            writer.print("X-Attachment: " + safeFile + "\r\n");
            writer.print("Content-Type: text/plain; charset=UTF-8\r\n\r\n");
            writer.print(body + "\r\n");
            if (!"None".equals(safeFile)) {
                writer.print("\r\n[Attached File: " + safeFile + "]\r\n");
            }
            writer.print(".\r\n");
            writer.flush();

            log.append("C->S: [Đã truyền nội dung thư + Header + dấu chấm kết thúc DATA]\n");
            String dataResp = reader.readLine();
            log.append("S->C: ").append(dataResp).append("\n");

            sendCmd(writer, reader, log, "QUIT");

            // Lưu vào mục [SENT] trong file data/<sender>.txt (và nếu người nhận cũng có file nội bộ thì cập nhật luôn)
            String now = FileManager.getCurrentTime();
            String localReceiverName = receiverEmail.contains("@")
                    ? receiverEmail.substring(0, receiverEmail.indexOf('@'))
                    : receiverEmail;
            Email emailObj = new Email(now, senderAcc.getUsername(), receiverEmail, subject, body, safeFile);
            senderAcc.getSent().add(emailObj);
            fileManager.saveAccount(senderAcc);

            if (fileManager.userExists(localReceiverName) && !localReceiverName.equalsIgnoreCase(senderAcc.getUsername())) {
                Account recvAcc = fileManager.loadAccount(localReceiverName);
                recvAcc.getInbox().add(emailObj);
                fileManager.saveAccount(recvAcc);
            }

            log.append("===> THÀNH CÔNG: Đã gửi qua Socket SMTP Server (").append(smtpHost).append(":")
                    .append(smtpPort).append(") và lưu vào data/").append(senderAcc.getUsername()).append(".txt!\n");
            this.lastProtocolLog = log.toString();
            this.lastStatusMessage = "Đã gửi qua SMTP Server " + smtpHost + ":" + smtpPort + " thành công!";
            return true;

        } catch (Exception ex) {
            log.append("===> LỖI KẾT NỐI SOCKET TỚI SMTP SERVER (").append(smtpHost).append(":").append(smtpPort).append("): ")
                    .append(ex.getMessage()).append("\n");
            log.append("💡 Gợi ý: Nếu bạn chưa bật phần mềm Mail Server ngoài (như hMailServer/James), hãy chọn chế độ 'Localhost (Nội bộ)' hoặc bật nút 'Chạy Local Socket Server (2525/1110)' ngay trên thanh công cụ GUI!\n");
            this.lastProtocolLog = log.toString();
            this.lastStatusMessage = "Không kết nối được tới " + smtpHost + ":" + smtpPort + " (" + ex.getMessage() + ")";
            return false;
        }
    }

    private void sendCmd(PrintWriter writer, BufferedReader reader, StringBuilder log, String cmd) throws Exception {
        log.append("C->S: ").append(cmd).append("\n");
        writer.print(cmd + "\r\n");
        writer.flush();
        String resp = reader.readLine();
        log.append("S->C: ").append(resp).append("\n");
    }

    /**
     * Tích hợp bài mẫu diachi.java: Tự động phát hiện và phân tích các URL có trong nội dung Email.
     */
    private void appendUrlAnalysisIfPresent(String text, StringBuilder log) {
        if (text == null || text.isEmpty()) return;
        Matcher m = Pattern.compile("(https?://[^\\s]+)", Pattern.CASE_INSENSITIVE).matcher(text);
        while (m.find()) {
            String rawUrl = m.group(1);
            try {
                URL url = new URL(rawUrl);
                log.append("[Phân tích URL trong Email - diachi.java]\n");
                log.append("  URL          : ").append(url.toString()).append("\n");
                log.append("  protocol     : ").append(url.getProtocol()).append("\n");
                log.append("  authority    : ").append(url.getAuthority()).append("\n");
                log.append("  host         : ").append(url.getHost()).append("\n");
                log.append("  port         : ").append(url.getPort()).append(" (default: ").append(url.getDefaultPort()).append(")\n");
                log.append("  path / file  : ").append(url.getPath()).append(" / ").append(url.getFile()).append("\n");
                log.append("  query / ref  : ").append(url.getQuery()).append(" / ").append(url.getRef()).append("\n");
            } catch (Exception ignored) {
            }
        }
    }
}